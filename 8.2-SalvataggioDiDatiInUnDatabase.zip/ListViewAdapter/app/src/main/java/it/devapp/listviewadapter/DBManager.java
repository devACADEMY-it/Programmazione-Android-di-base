/*
 * Programmazione Android di base
 * Salvataggio di dati in un database
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DBManager {

    private DBHelper helper;
    private Context context;

    DBManager(Context ctx){
        context = ctx;
        helper = new DBHelper(ctx, "TODO", null, 1);
    }

    void nuovoRecord (String testo){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("testo", testo);
        db.insert("TodoList", null, cv);
    }

}