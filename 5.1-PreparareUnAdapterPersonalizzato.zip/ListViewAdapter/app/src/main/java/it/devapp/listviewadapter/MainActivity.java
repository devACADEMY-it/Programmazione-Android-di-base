/*
 * Programmazione Android di base
 * Preparare un Adapter personalizzato
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    private ArrayAdapter <Promemoria> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista = (ListView) findViewById(R.id.lista);
        adapter = new ArrayAdapter<Promemoria>(this, R.layout.promemoria_layout, R.id.testo_promemoria, new ArrayList<Promemoria>());
        lista.setAdapter(adapter);
    }

    public void nuovaAttivita(View v){
        EditText et = (EditText) findViewById(R.id.todo);
        String t = et.getText().toString();

        if (t.length() == 0)
            return;
        Promemoria p = new Promemoria();
        p.setTesto(t);
        adapter.add(p);

        et.setText("");
    }

    public void modificaImportanza(View v){
        int pos = lista.getPositionForView(v);

        Toast.makeText(this, "Stellina alla riga " + pos, Toast.LENGTH_SHORT).show();
    }
}