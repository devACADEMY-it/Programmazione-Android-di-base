/*
 * Programmazione Android di base
 * ListView e Adapter
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    private ArrayAdapter <Promemoria> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void nuovaAttivita(View v){
        EditText et = (EditText) findViewById(R.id.todo);
        et.setText("");


    }
}