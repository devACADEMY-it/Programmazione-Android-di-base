/*
 * Programmazione Android di base
 * Integrazione di un database
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.content.Context;

public class DBManager {

    private DBHelper helper;
    private Context context;

    DBManager(Context ctx){
        Context = ctx;
        helper = new DBHelper(ctx, "TODO", null, 1);
    }

}