/*
 * Programmazione Android di base
 * Cancellazione di record
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.StringWriter;

public class DBManager {

    private DBHelper helper;
    private Context context;

    DBManager(Context ctx){
        context = ctx;
        helper = new DBHelper(ctx, "TODO", null, 1);
    }

    void cancellaAttivita (int id){
        SQLiteDatabase db = helper.getWritableDatabase();
        String recordId = Integer.toString(id);
        db.delete("TodoList", "_id=?", new String[] {recordId});
    }

    void cancellaLista (){
        SQLiteDatabase db = helper.getWritableDatabase();
        db.delete("TodoList", null, null);
    }

    void modificaImportanza(int id, boolean importante){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        if (importante){
            cv.put("importante", 1);
        } else {
            cv.put("importante", 0);
        }

        String recordId = Integer.toString(id);
        db.update("TodoList", cv, "_id=?", new String[] {recordId} );
    }

    Cursor elencoAttivita(){
        SQLiteDatabase db = helper.getReadableDatabase();
        return db.query("TodoList", null, null, null, null, null, null);
    }

    void nuovoRecord (String testo){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("testo", testo);
        db.insert("TodoList", null, cv);
    }

}