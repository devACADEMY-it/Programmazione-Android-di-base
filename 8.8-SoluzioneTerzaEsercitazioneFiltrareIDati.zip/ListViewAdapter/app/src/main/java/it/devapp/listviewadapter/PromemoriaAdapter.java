/*
 * Programmazione Android di base
 * Soluzione Terza Esercitazione: "Filtrare i dati"
 *
 * Disponibile su devACADEMY.it
 */


package it.devapp.listviewadapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class PromemoriaAdapter extends ArrayAdapter<Promemoria> {

    public PromemoriaAdapter(Context context, int resource, int textViewResourceId, List<Promemoria> objects) {
        super(context, resource, textViewResourceId, objects);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = getDropDownView(position, convertView, parent);
        Promemoria tmp = getItem(position);
        TextView txt = (TextView) v.findViewById(R.id.testo_promemoria);
        txt.setText(tmp.getTesto());
        return v;
    }
}