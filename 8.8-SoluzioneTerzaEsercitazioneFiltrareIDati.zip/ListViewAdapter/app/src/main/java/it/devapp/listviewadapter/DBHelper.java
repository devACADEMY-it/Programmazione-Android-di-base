/*
 * Programmazione Android di base
 * Soluzione Terza Esercitazione: "Filtrare i dati"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper  extends SQLiteOpenHelper{

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql= "CREATE TABLE TodoList (" +
                "_id INTEGER PRIMARY KEY," +
                "testo TEXT," +
                "descrizione TEXT," +
                "importante INTEGER)";

        db.execSQL(sql);



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}