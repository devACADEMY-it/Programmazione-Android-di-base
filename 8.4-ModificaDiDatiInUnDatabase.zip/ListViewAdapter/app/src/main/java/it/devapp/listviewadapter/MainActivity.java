/*
 * Programmazione Android di base
 * Modifica di dati in un database
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.media.Image;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    private SimpleCursorAdapter adapter;
    private DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbManager = new DBManager(this);

        lista = (ListView) findViewById(R.id.lista);

        adapter = new SimpleCursorAdapter(this, R.layout.promemoria_layout, dbManager.elencoAttivita(),
                  new String[]{"testo"}, new int[]{R.id.testo_promemoria}, 0){
            
            @Override
            public void bindView(View view, Context context, Cursor cursor) {
                super.bindView(view, context, cursor);

                ImageView stellina = (ImageView) view.findViewById(R.id.importante);
                int importante = cursor.getInt(cursor.getColumnIndex("importante"));

                if(importante==0){
                    stellina.setImageResource(android.R.drawable.star_big_off);
                } else {
                    stellina.setImageResource(android.R.drawable.star_big_on);
                }
            }
        };

        lista.setAdapter(adapter);

        lista.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE_MODAL);

        lista.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                getMenuInflater().inflate(R.menu.cab, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                switch (item.getItemId()){
                    case R.id.action_cancella_voce:
                        SparseBooleanArray a = lista.getCheckedItemPositions();
                        for (int i = a.size()-1; i >= 0; i--){
                            //if (a.valueAt(i))
                            //    adapter.remove(adapter.getItem(a.keyAt(i)));
                        }
                }

                mode.finish();
                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {

            }

            @Override
            public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
                int checkedCount = lista.getCheckedItemCount();
                mode.setTitle(checkedCount + " Selezionati");
            }
        });

        lista.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        View layout = LayoutInflater.from(MainActivity.this).inflate(R.layout.dialog_layout, null);

                        builder.setView(layout);
                        builder.setTitle("Modifica attività");
                        //final Promemoria p = adapter.getItem(position);

                        final EditText et_testo = (EditText) layout.findViewById(R.id.dialog_testo);
                        final EditText et_descrizione = (EditText) layout.findViewById(R.id.dialog_descrizione);

                        final ImageButton cancellaTesto = (ImageButton) layout.findViewById(R.id.cancellaTesto);
                        final ImageButton cancellaDescrizione = (ImageButton) layout.findViewById(R.id.cancellaDescrizione);

                        cancellaTesto.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                et_testo.setText("");
                            }
                        });

                        cancellaDescrizione.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                et_descrizione.setText("");
                            }
                        });

                        /*
                        et_testo.setText(p.getTesto());
                        et_descrizione.setText(p.getDescrizione());

                        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                p.setTesto(et_testo.getText().toString());
                                p.setDescrizione(et_descrizione.getText().toString());
                            }
                        });
                        */

                        builder.setNegativeButton("No", null);

                        builder.show();

                    }
                }
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case R.id.action_svuota:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Operazione irreversibile");
                builder.setMessage("La lista sarà svuotata. Procedere?");
                builder.setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //adapter.clear();
                    }
                });
                builder.setNegativeButton("No", null);
                builder.show();
                break;
        }

        return true;
    }

    public void nuovaAttivita(View v){
        EditText et = (EditText) findViewById(R.id.todo);
        String t = et.getText().toString();

        if (t.length() == 0)
            return;
        Promemoria p = new Promemoria();
        p.setTesto(t);

        dbManager.nuovoRecord(t);
        adapter.changeCursor(dbManager.elencoAttivita());

        et.setText("");
    }

    public void modificaImportanza(View v){
        int pos = lista.getPositionForView(v);

        Cursor c = adapter.getCursor();
        c.moveToPosition(pos);

        int id = c.getInt(c.getColumnIndex("_id"));
        int importante = c.getInt(c.getColumnIndex("importante"));

        if(importante==0){
            dbManager.modificaImportanza(id, true);
        } else {
            dbManager.modificaImportanza(id, false);
        }

        adapter.changeCursor(dbManager.elencoAttivita());

    }


}