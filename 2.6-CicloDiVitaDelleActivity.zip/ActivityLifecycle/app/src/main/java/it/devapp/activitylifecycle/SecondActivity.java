/*
 * Programmazione Android di base
 * Ciclo di vita delle Activity
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.activitylifecycle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    private static String TAG="Test-SecondActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        getSupportActionBar().setHomeButtonEnabled(true);

        String s=getIntent().getStringExtra(MainActivity.EXTRA);

        Toast.makeText(this,"MainActivity dice: "+s,Toast.LENGTH_LONG).show();
        Log.d(TAG, "Fine onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Fine onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Fine onResume");
    }
}
