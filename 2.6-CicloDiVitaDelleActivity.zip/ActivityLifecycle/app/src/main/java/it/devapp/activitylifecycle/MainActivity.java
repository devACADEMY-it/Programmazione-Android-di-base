/*
 * Programmazione Android di base
 * Ciclo di vita delle Activity
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.activitylifecycle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA = "extra_string";
    private static String TAG="Test-MainActivity";
    private EditText txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (EditText) findViewById(R.id.testo);

        Log.d(TAG, "Fine onCreate");
    }

    public void cambiaActivity(View v)
    {
        String testoDaPassare=txt.getText().toString();

        Intent i=new Intent(this,SecondActivity.class);
        i.putExtra(EXTRA, testoDaPassare);

        startActivity(i);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Fine onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Fine onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Fine onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Fine onStop");
    }

}
