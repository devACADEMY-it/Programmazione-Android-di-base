/*
 * Programmazione Android di base
 * Soluzione Prima Esercitazione: "Modificare un layout"
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void salutami(View v){
        EditText et_nome = (EditText) findViewById(R.id.nome);
        EditText et_cognome = (EditText) findViewById(R.id.cognome);

        String nome = et_nome.getText().toString();
        String cognome = et_cognome.getText().toString();

        Toast.makeText(this, "Ciao " + nome + " " + cognome + "!", Toast.LENGTH_LONG).show();
    }
}