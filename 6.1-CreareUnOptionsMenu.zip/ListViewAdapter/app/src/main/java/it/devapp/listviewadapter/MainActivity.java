/*
 * Programmazione Android di base
 * Creare un OptionsMenu
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    private PromemoriaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista = (ListView) findViewById(R.id.lista);
        adapter = new PromemoriaAdapter(this, R.layout.promemoria_layout, R.id.testo_promemoria, new ArrayList<Promemoria>());
        lista.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id) {
            case R.id.action_svuota:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Operazione irreversibile");
                builder.setMessage("La lista sarà svuotata. Procedere?");
                builder.setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        adapter.clear();
                    }
                });
                builder.setNegativeButton("No", null);
                builder.show();
                break;
        }

        return true;
    }

    public void nuovaAttivita(View v){
        EditText et = (EditText) findViewById(R.id.todo);
        String t = et.getText().toString();

        if (t.length() == 0)
            return;
        Promemoria p = new Promemoria();
        p.setTesto(t);
        adapter.add(p);

        et.setText("");
    }

    public void modificaImportanza(View v){
        int pos = lista.getPositionForView(v);
        //Toast.makeText(this, "Stellina alla riga " + pos, Toast.LENGTH_SHORT).show();
        Promemoria tmp = adapter.getItem(pos);
        tmp.setImportante(!tmp.isImportante());

        ImageView img = (ImageView) v;

        if (tmp.isImportante())
            img.setImageResource(android.R.drawable.star_big_on);
        else
            img.setImageResource(android.R.drawable.star_big_off);
    }


}