/*
 * Programmazione Android di base
 * Contextual Action Bar
 *
 * Disponibile su devACADEMY.it
 */

package it.devapp.listviewadapter;

public class Promemoria {
    private String testo;
    private String descrizione;
    private boolean importante;

    public String getTesto() {
        return testo;
    }

    public void setTesto(String testo) {
        this.testo = testo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public boolean isImportante() {
        return importante;
    }

    public void setImportante(boolean importante) {
        this.importante = importante;
    }

    @Override
    public String toString() {
        return testo;
    }
}